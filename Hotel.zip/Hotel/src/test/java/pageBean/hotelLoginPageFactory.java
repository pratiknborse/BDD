package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class hotelLoginPageFactory {

	WebDriver driver;
	
	//step 1: identify elements
	@FindBy(name="userName")
	WebElement pfuname;
	
	//using how class
	@FindBy(how=How.NAME, using = "userPwd")
	WebElement pfpwd;

	@FindBy(className="btn")
	WebElement pflogin;

	//initiating the elements
	public hotelLoginPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	
	
	//setters and getters
	
	public void setPfuname(String suname) {
		pfuname.sendKeys(suname);
	}
	public void setPfpwd(String spwd) {
		pfpwd.sendKeys(spwd);
	}
	public void setPflogin() {
		pflogin.click();
	}
	
	public WebElement getPfuname() {
		return pfuname;
	}
	public WebElement getPfpwd() {
		return pfpwd;
	}
	public WebElement getPflogin() {
		return pflogin;
	}
	
	
	
}
